var request = require('request');
var fs = require('fs');

//save data to file 
function saveData(data){

    console.log(data);
    
    fs.writeFile("users-data.json", data, (err) => {
        if (err) {
          console.error(err)
          throw err
        }
    
        console.log('Saved data to file.')
      });      

}


//get data 
function getData(){



        request.get('https://jsonplaceholder.typicode.com/todos',(err,res,body)=>{

                if(err)
                {
                    console.log(err)
                }
                else {
                        var data  = JSON.parse(body);
                        //console.log(data);
                        data = JSON.stringify(data); //covert data to string 
                        saveData(data);

                }
        });

    }


    //call to function 
    getData();
